import pandas as pd
import pytest
import numpy as np
import unittest
from .nodes import preprocess_data
from .nodes import normalize_data


# the preprocess_data function goes here

 
def input_data():
    return pd.DataFrame({
        'column1': [1, 2, None, 4],
        'column2': [1, None, 3, 4],
        'column3': [1, None, None, None]
    })


def expected_output():
    return pd.DataFrame({
        'column1': [1],
        'column2': [1],
        'column3': [1]
    })



def test_preprocess_data():
    # Créer un DataFrame pour tester
    df = pd.DataFrame({
        "col1": [1, 2, np.nan, 4, 5],
        "col2": [np.nan, 2, 3, 4, 5]
    })

    # Exécuter la fonction de prétraitement des données
    processed_df = preprocess_data(df)

    # Vérifier que toutes les lignes contenant des NaN ont été supprimées
    assert processed_df.isnull().sum().sum() == 0, "Il y a des valeurs NaN après le prétraitement"

    # Vérifier que le nombre de lignes est correct
    assert len(processed_df) == 3, "Le nombre de lignes après le prétraitement est incorrect"



def test_normalize_data():
    # Créer un DataFrame pour tester
    df = pd.DataFrame({
        "col1": [10, 20, 30, 40, 50],
        "col2": [2, 4, 6, 8, 10]
    })

    # Exécuter la fonction de normalisation des données
    normalized_df = normalize_data(df)

    # Vérifier que toutes les valeurs se situent entre 0 et 1
    assert normalized_df.max().max() == 1, "Valeur maximale après normalisation n'est pas 1"
    assert normalized_df.min().min() == 0, "Valeur minimale après normalisation n'est pas 0"
    assert not normalized_df.isnull().values.any(), "Il y a des valeurs NaN après normalisation"
