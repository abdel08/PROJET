"""
This is a boilerplate pipeline 'analyse'
generated using Kedro 0.18.10
"""

from kedro.pipeline import Pipeline, node 
from .nodes import preprocess_data, normalize_data, split_data




def create_pipeline(**kwargs) -> Pipeline:
    '''init pipeline'''
    return Pipeline([
        node(
             func=preprocess_data,
             inputs="raw_daily_data",
             outputs="shaped_datas",
             name="node_merge_raw_daily_data"
            ),
            node(
             func=normalize_data,
             inputs="shaped_datas",
             outputs="normaliser_data",
             name="node_merge_raw_daily"
            ),
            node(
             func=split_data,
             inputs="normaliser_data",
             outputs=["train_df_x", "train_df_y", "test_df_x", "test_df_y"],
             name="node_normaliser"
            )
    ])
    

