"""
This is a boilerplate pipeline 'analyse1'
generated using Kedro 0.18.10
"""
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error


def preprocess_data(input_datas: pd.DataFrame) -> pd.DataFrame:
    # Suppression des lignes contenant des valeurs vides
    shaped_datas = input_datas.dropna(axis=0, how='any')
    return shaped_datas


def normalize_data(dataframe):
    return (dataframe - dataframe.min()) / (dataframe.max() - dataframe.min())


def split_data(input_datas: pd.DataFrame) :
    # Récupération de 20% des données pour le test du modèle
    dfx = input_datas.loc[:, ['before_exam_125_Hz', 'before_exam_250_Hz', 'before_exam_500_Hz', 'before_exam_1000_Hz', 'before_exam_2000_Hz', 'before_exam_4000_Hz', 'before_exam_8000_Hz']]
    dfy = input_datas.loc[:, ['after_exam_125_Hz', 'after_exam_250_Hz', 'after_exam_500_Hz', 'after_exam_1000_Hz', 'after_exam_2000_Hz', 'after_exam_4000_Hz', 'after_exam_8000_Hz']]
    train_df_x, test_df_x, train_df_y, test_df_y = train_test_split(dfx, dfy, test_size=0.2)

    print("**VARIABLE TRAIN**")
    print(train_df_x, train_df_y)
    print("**VARIABLE TEST**")
    print(test_df_x, test_df_y)
    return train_df_x, train_df_y, test_df_x, test_df_y



