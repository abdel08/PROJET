"""
This is a boilerplate pipeline 'pipeline_name'
generated using Kedro 0.18.11
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import make_predictions


def create_pipeline(**kwargs) -> Pipeline:
    return Pipeline([
        node(
            func= make_predictions,
            inputs="data_user",
            outputs="predictions",
            name="rained_data"
        )
    ])