import pandas as pd
import pytest
from .nodes import make_predictions
import numpy as np



def test_make_predictions():
    # Données d'entrée
    input_data = np.array([
    [0.23, 0.0485436893203883, 0.7570093457943925, 0.7272727272727273, 0.2566371681415929, 0.1623931623931624, 0.6416666666666667],
    [0.64, 0.116504854368932, 0.7009345794392523, 0.5818181818181818, 0.5929203539823009, 0.7777777777777778, 0.2333333333333333],
    ])  

    # Appeler la fonction pour faire des prédictions
    predictions = make_predictions(input_data)

    # Afficher les prédictions
    print(predictions)
    assert predictions is not None 