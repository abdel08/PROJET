import mlflow
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd

def make_predictions(data_user):
    # Charger le modèle à partir de MLflow
    model = mlflow.tensorflow.load_model("runs:/e86a50f90a124469a05b0ac061e5bed1/model")
   
    # Prédictions
    predictions = model.predict(data_user)
    print(predictions)
    return pd.DataFrame(predictions)


