from sklearn.model_selection import train_test_split
from tensorflow.keras import layers
import tensorflow as tf
from tensorflow.keras import layers, regularizers
import mlflow
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split



def create_model(input_shape, units=100, activation='relu', l2_value=0.01, dropout_rate=0.3, learning_rate=1e-3):
    inputs = layers.Input(shape=input_shape)
    x = layers.Conv1D(filters=64, kernel_size=3, activation=activation)(inputs)
    x = layers.MaxPooling1D(pool_size=2)(x)
    x = layers.ZeroPadding1D(padding=1)(x) 
    x = layers.Conv1D(filters=128, kernel_size=3, activation=activation)(x)
    x = layers.ZeroPadding1D(padding=1)(x) 
    x = layers.MaxPooling1D(pool_size=2)(x)
    x = layers.Flatten()(x)
    x = layers.Dense(units, activation='relu', kernel_regularizer=regularizers.l2(l2_value))(x)
    if dropout_rate is not None:
        x = layers.Dropout(dropout_rate)(x)

    x = layers.Dense(input_shape[0], activation='linear')(x)
    model = tf.keras.Model(inputs=inputs, outputs=x)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
            loss="mse", metrics=[tf.keras.metrics.MeanSquaredError()])
    return model

def training_model(train_df_x, train_df_y, test_df_x, test_df_y, epochs=10):
    input_shape = train_df_x.shape[1:]
    mlflow.autolog()
    model = create_model(input_shape=(input_shape[0],1))
    early_stopping = EarlyStopping(monitor='val_loss', patience=10)
    model.fit(train_df_x, train_df_y, epochs=epochs, validation_data=(test_df_x, test_df_y), callbacks=[early_stopping])
    return model








