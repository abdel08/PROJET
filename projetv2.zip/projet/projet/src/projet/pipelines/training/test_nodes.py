import pandas as pd
import pytest
from .nodes import training_model

def test_training_model():
    # Créer des données factices pour tester
    train_df_x = pd.read_csv("C:\\Users\\mousa\\projet\\data\\05_model_input\\test_labels.csv")
    train_df_y = pd.read_csv("C:\\Users\\mousa\\projet\\data\\05_model_input\\test.csv")
    test_df_x = pd.read_csv("C:\\Users\\mousa\\projet\\data\\05_model_input\\train_labels.csv")
    test_df_y = pd.read_csv("C:\\Users\\mousa\\projet\\data\\05_model_input\\train.csv")

    # Essayer d'exécuter la fonction d'entraînement du modèle
   
    model = training_model(train_df_x, train_df_y, test_df_x, test_df_y)
   

    # Vérifiez que le modèle a été créé avec succès
    assert model is not None 


