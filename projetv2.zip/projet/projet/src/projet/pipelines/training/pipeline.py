"""
This is a boilerplate pipeline 'pipeline_name'
generated using Kedro 0.18.11
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import training_model


def create_pipeline(**kwargs) -> Pipeline:
    return Pipeline([
        node(
            func= training_model,
            inputs=["train_df_x", "train_df_y", "test_df_x", "test_df_y"],
            outputs="trained_model",
            name="node_trained_data"
        )
    ])